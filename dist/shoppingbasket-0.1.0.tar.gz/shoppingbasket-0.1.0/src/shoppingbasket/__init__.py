"""A Python library with functionality for calculating the price of baskets of products, including functionality to account for product promotions."""

__version__ = "0.1.0"
